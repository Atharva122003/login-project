from urllib import request
from django.shortcuts import render

from django.db import connection
from .models import userinfo

# Create your views here.
def GetRagisterpage(request):
    return render(request,'ragitration.html')

def GetLoginpage(request):
    return render(request,'login.html')

def GetUsercurdpage(request):
    return render(request,'usercurd.html')

def GetShowallpage(request):
      userdb=userinfo.objects.all()  
      return render(request,'showall.html',{'userdb':userdb})

def Gethomepage(request):
    return render(request,'usercurd.html')

def registeruser(request):
   # corrected code
    username = request.GET.get('username')
    password = request.GET.get('password')
    mobNo = request.GET.get('mobNo')  # match the model field exactly

    userinfo.objects.create(username=username, password=password, mobNo=mobNo)


    return render(request,'login.html',{'msg':'User Registered Successfully!!!!'})

def loginuser(request):
    username=request.GET['username']
    password = request.GET['password']
    userdb = userinfo.objects.get(username=username)

    request.session['username']=username

    if userdb.password == password:
        return render(request,'home.html',{'msg':'Login Successful!!!!'})
    else:
        return render(request,'login.html',{'msg':'Invalid credentials!!!!'})
    
def Add_user(request):
        username = request.GET.get('username')
        password = request.GET.get('password')
        mobNo = request.GET.get('mobNo')  # match the model field exactly

        userinfo.objects.create(username=username, password=password, mobNo=mobNo)

        print(connection.queries)
        return render(request,'usercurd.html',{'msg':'User Added successfully!!!!'})

        
def show_user(request):
     try:
        username = request.GET.get('username')
        userdb=userinfo.objects.get(username=username)
        print(connection.queries)

        return render(request,'usercurd.html',{'userdb':userdb})
     except Exception as e:
         e="username doesnot match!!!"
         return render(request,'usercurd.html',{'msg':e})
     
def update_user(request):
            username = request.GET.get('username')
            userdb=userinfo.objects.filter(username=username)
            userdb.update(
                 password=request.GET.get('password'),
                 mobNo=request.GET.get('mobNo'),
            )
            print(connection.queries)

            return render(request,'usercurd.html',{'userdb':userdb,'msg':'User Updated successfully!!!!'})  


def delete_user(request):
            
            username = request.GET.get('username')
            userdb=userinfo.objects.filter(username=username).delete()
            print(connection.queries)

            return render(request,'usercurd.html',{'msg':'User Deleted successfully!!!!'})  

def Deleteusershowall(request):


    username = request.GET.get('username')
    userdb=userinfo.objects.filter(username=username).delete()

    userdb=userinfo.objects.all()
    return render(request,'showall.html',{'userdb':userdb})