
from django.urls import path

from . import views


urlpatterns = [
    path('', views.Gethomepage),
    path('getragiserpage/',views.GetRagisterpage),
    path('getloginpage/', views.GetLoginpage),
    path('getusercurdpage/', views.GetUsercurdpage),
    path('getshowallpage/', views.GetShowallpage),


    path('registeruser/', views.registeruser),
    path('loginuser/', views.loginuser),
   

   path('adduser/', views.Add_user),
    path('showuser/', views.show_user),
    path('updateuser/', views.update_user),
    path('deleteuser/', views.delete_user),

    path('deleteusershowall/', views.Deleteusershowall),
]